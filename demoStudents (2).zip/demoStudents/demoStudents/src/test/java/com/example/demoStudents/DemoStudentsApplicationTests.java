package com.example.demoStudents;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
