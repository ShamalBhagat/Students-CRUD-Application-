package com.example.demoStudents.services;

import com.example.demoStudents.models.StudentMaster;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

public interface StudentService {

    List<StudentMaster> getAllStudents();

    Optional<StudentMaster> getStudentsById(Long id);

    StudentMaster createStudents(StudentMaster id);

     StudentMaster updateStudents(StudentMaster updatedStudents);

    void deleteStudents(Long id);


}
