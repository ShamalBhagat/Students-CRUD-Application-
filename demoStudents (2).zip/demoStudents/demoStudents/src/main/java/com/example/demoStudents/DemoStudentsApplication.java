package com.example.demoStudents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoStudentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoStudentsApplication.class, args);
		System.out.println(" Student Application Running! ");
	}

}
