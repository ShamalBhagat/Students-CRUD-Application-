package com.example.demoStudents.controllers;

import com.example.demoStudents.models.StudentMaster;
import com.example.demoStudents.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentService studentService;


    @PostMapping("/create")
    public ResponseEntity<StudentMaster> createStudents(@RequestBody StudentMaster communityId) {
        StudentMaster createdCommunity = studentService.createStudents(communityId);
        return new ResponseEntity<>(createdCommunity, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<StudentMaster> updateStudents( @RequestBody StudentMaster updatedStudents) {
        StudentMaster updated = studentService.updateStudents(updatedStudents);
        return updated != null ?
                new ResponseEntity<>(updated, HttpStatus.OK) :
                new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }


    @GetMapping("/getAll/Students")
    public ResponseEntity<List<StudentMaster>> getAllStudents() {
        List<StudentMaster> communities = studentService.getAllStudents();
        return new ResponseEntity<>(communities, HttpStatus.OK);
    }

    @GetMapping("/getById/{id}")
    public ResponseEntity<StudentMaster> getStudentsById(@PathVariable Long id) {
        Optional<StudentMaster> foundCommunity = studentService.getStudentsById(id);
        return foundCommunity.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/deleteById/{id}")
    public ResponseEntity<java.lang.Void> deleteStudents(@PathVariable Long id) {
        studentService.deleteStudents(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

}
