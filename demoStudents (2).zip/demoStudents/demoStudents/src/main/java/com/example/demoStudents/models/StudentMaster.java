package com.example.demoStudents.models;


import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Student_Details")
public class StudentMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column
    private String name;
    @Column
    private String email;
    @Column
    private Double mobileNumber;
    @Column
    private String address;

}
