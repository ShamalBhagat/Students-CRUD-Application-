package com.example.demoStudents.Dto.Request;

import lombok.Data;

@Data
public class StudentReq {
    private Long id;
    private String name;
    private String email;
    private Double mobileNumber;
    private String address;
}
