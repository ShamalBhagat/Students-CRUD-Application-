package com.example.demoStudents.services.Impl;

import com.example.demoStudents.models.StudentMaster;
import com.example.demoStudents.repository.StudentRepository;
import com.example.demoStudents.services.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public List<StudentMaster> getAllStudents() {
        return studentRepository.findAll();
    }

    @Override
    public Optional<StudentMaster> getStudentsById(Long id) {
        return  studentRepository.findById(id);

    }

    @Override
    public StudentMaster createStudents(StudentMaster studentMaster) {
        return  studentRepository.save( studentMaster);
    }

    @Override
    public StudentMaster updateStudents(StudentMaster studentMaster) {
        return  studentRepository.save(studentMaster);
    }

    @Override
    public void deleteStudents(Long id) {
         studentRepository.deleteById(id);
    }


}

